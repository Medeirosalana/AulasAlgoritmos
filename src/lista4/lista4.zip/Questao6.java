package lista4;


public class Questao6 {
    public static void main(String[] args) {
        
    }
}
